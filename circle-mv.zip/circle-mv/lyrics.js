// lyrics.js: one entry per lyric line.
// start/end are in seconds (from the song). text is what appears on screen.
// These 8 entries are PLACEHOLDERS so you can test the engine.
// Replace them: run tools/srt_to_json.py with your Descript SRT, or edit by hand.
window.LYRICS = [
  { start: 4.0,  end: 8.0,  text: "LINE ONE TEXT" },
  { start: 8.0,  end: 12.0, text: "LINE TWO TEXT" },
  { start: 12.0, end: 16.0, text: "LINE THREE TEXT" },
  { start: 16.0, end: 20.0, text: "LINE FOUR TEXT" },
  { start: 20.0, end: 24.0, text: "LINE FIVE TEXT" },
  { start: 24.0, end: 28.0, text: "LINE SIX TEXT" },
  { start: 28.0, end: 32.0, text: "LINE SEVEN TEXT" },
  { start: 32.0, end: 36.0, text: "LINE EIGHT TEXT" }
];
window.SONG_DURATION = 181.4;
