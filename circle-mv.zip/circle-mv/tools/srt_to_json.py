#!/usr/bin/env python3
"""Turn an SRT (e.g. exported from Descript) into lyrics.js.

Usage:
  python3 tools/srt_to_json.py captions.srt                 # keeps SRT text as-is
  python3 tools/srt_to_json.py captions.srt hinglish.txt    # swaps in your own text,
                                                            # one line per SRT cue
"""
import re, sys, json

def ts(s):
    h, m, rest = s.strip().split(":")
    sec, ms = rest.replace(",", ".").split(".")
    return int(h) * 3600 + int(m) * 60 + int(sec) + int(ms) / 1000

srt = open(sys.argv[1], encoding="utf-8").read().replace("\r", "")
cues = []
for block in re.split(r"\n\s*\n", srt.strip()):
    lines = block.split("\n")
    idx = next((i for i, l in enumerate(lines) if "-->" in l), None)
    if idx is None:
        continue
    a, b = lines[idx].split("-->")
    cues.append({"start": round(ts(a), 2), "end": round(ts(b), 2),
                 "text": " ".join(lines[idx + 1:]).strip()})

if len(sys.argv) > 2:
    mine = [l.strip() for l in open(sys.argv[2], encoding="utf-8") if l.strip()]
    if len(mine) != len(cues):
        sys.exit(f"Mismatch: {len(cues)} SRT cues but {len(mine)} text lines.")
    for c, t in zip(cues, mine):
        c["text"] = t

with open("lyrics.js", "w", encoding="utf-8") as f:
    f.write("window.LYRICS = " + json.dumps(cues, ensure_ascii=False, indent=2) + ";\n")
    f.write("window.SONG_DURATION = 181.4;\n")
print(f"Wrote lyrics.js with {len(cues)} lines")
