# Circle - ASHIX lyric video (16:9, 1920x1080)

Status: NOT RENDERED. Syntax-checked only; never run in a browser yet.

## Files
- index.html: composition (scenes, cameras, wipes, kinetic text). Timeline is registered on window.__timelines["circle-mv"].
- lyrics.js: lyric lines + timings. Currently 8 placeholder lines.
- assets/circle.mp3: the song.
- tools/srt_to_json.py: SRT (e.g. Descript export) -> lyrics.js.

## Fill the lyrics
1. Get an SRT of the vocals (Descript transcript -> export captions).
2. Write your Hinglish text, one line per SRT cue, in hinglish.txt.
3. python3 tools/srt_to_json.py captions.srt hinglish.txt

## Render from a phone (cloud)
Open this folder in GitHub Codespaces (browser), then use the HyperFrames CLI
(see its docs for the current preview/render commands). Output: 1080p MP4.
Notes:
- GSAP loads from cdnjs; the render machine needs internet, or save gsap.min.js next to index.html.
- Fonts use Impact/Arial Black fallbacks. Inline a font as base64 for identical results.
- If the render complains about audio attributes, check the HyperFrames docs for the audio tag format.
